java -jar api/server.jar france -1 player1 9090
