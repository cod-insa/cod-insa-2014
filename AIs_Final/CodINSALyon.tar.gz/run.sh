#!/usr/bin/env bash
./launch.sh ./FinalDraftAI.py $@
