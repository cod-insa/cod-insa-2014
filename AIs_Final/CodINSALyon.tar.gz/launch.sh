#!/bin/bash

./jython -Dpython.security.respectJavaAccessibility=false $@
