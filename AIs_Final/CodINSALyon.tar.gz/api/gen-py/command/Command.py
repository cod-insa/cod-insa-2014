class Command():
    SUCCESS = 0
    WARNING_COMMAND = -1
    ERROR_COMMAND = -2
    ERROR_TIME_OUT = -3
    ERROR_FORBIDDEN = -4
    ERROR_UNKNOWN = -5
    
    def __init__(self):
        pass