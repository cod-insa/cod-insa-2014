#!/usr/bin/env python
# -*- coding: utf-8 -*-

all_bases = {}
ennemy_planes = {}
killed_planes = {}
my_bases = {}
my_planes = {}
not_owned_and_not_visible_bases = {}
not_owned_and_visible_bases = {}
visible_bases = {}
my_production_line = {}
visited = {}
